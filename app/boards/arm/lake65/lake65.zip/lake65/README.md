# lake65


The nice!60 is a hotswap 65% made by shuiguohuooo. 

## Building nice!60 ZMK firmware
```
west build -p -b lake65
```
